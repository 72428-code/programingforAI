import numpy as np

data = np.array([
    [10, 20, 30, 40],
    [50, 60, 70, 80],
    [90, 100, 110, 120],
    [130, 140, 150, 160]
])

print("First row:")
print(data[0])

print("\nLast column:")
print(data[:, -1])

print("\nMiddle 2 x 2:")
print(data[1:3, 1:3])

print("\nEvery second row:")
print(data[::2])

print("\nValues greater than 75:")
print(data[data > 75])

print("\nValues divisible by 20:")
print(data[data % 20 == 0])