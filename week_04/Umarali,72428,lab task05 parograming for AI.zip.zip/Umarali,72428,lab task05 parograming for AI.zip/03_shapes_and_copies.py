import numpy as np

# View
original = np.array([10, 20, 30, 40, 50])

view = original[1:4]

view[0] = 999

print("Original after changing view:")
print(original)


# Copy
copy = original[1:4].copy()

copy[0] = 777

print("\nCopy:")
print(copy)

print("Original:")
print(original)


# Reshape
values = np.arange(1, 13)

matrix = values.reshape(3, 4)

print("\n3 x 4 Matrix:")
print(matrix)


# Transpose
transpose = matrix.T

print("\nTranspose:")
print(transpose)


# Flatten
flat = matrix.flatten()

print("\nFlatten:")
print(flat)


# Combine
a = np.array([[1, 2], [3, 4]])
b = np.array([[5, 6], [7, 8]])

vertical = np.vstack((a, b))
horizontal = np.hstack((a, b))

print("\nVertical:")
print(vertical)

print("\nHorizontal:")
print(horizontal)


# Split
parts = np.split(np.arange(12), 3)

print("\nSplit:")
print(parts)