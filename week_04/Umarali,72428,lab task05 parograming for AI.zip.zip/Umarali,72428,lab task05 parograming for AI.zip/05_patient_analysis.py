import numpy as np

patient_data = np.array([
    [101, 45, 38.5, 100, 92],
    [102, 23, 36.8, 75, 98],
    [103, 67, 39.1, 110, 89],
    [104, 54, 37.0, 80, 96],
    [105, 34, 38.0, 95, 93],
    [106, 72, 36.5, 70, 97]
], dtype=float)


# Basic information
print("Shape:", patient_data.shape)
print("Dimensions:", patient_data.ndim)
print("Size:", patient_data.size)
print("Data type:", patient_data.dtype)


# Separate ID and clinical data
patient_ids = patient_data[:, 0].astype(int)
clinical_features = patient_data[:, 1:]

print("\nPatient IDs:")
print(patient_ids)

print("\nClinical Features:")
print(clinical_features)


# Average age
average_age = np.mean(patient_data[:, 1])

print("\nAverage age:")
print(average_age)


# Mean of all clinical features
feature_means = np.mean(clinical_features, axis=0)

print("\nMean of clinical features:")
print(feature_means)


# Patients older than 60
older = patient_data[patient_data[:, 1] > 60]

print("\nPatients older than 60:")
print(older)


# Patients hotter than 38
hot = patient_data[patient_data[:, 2] > 38]

print("\nPatients hotter than 38:")
print(hot)


# Oxygen below 94
low_oxygen = patient_data[patient_data[:, 4] < 94]

print("\nPatients with oxygen below 94:")
print(low_oxygen)


# High-risk patients
high_risk_mask = (patient_data[:, 2] > 38) & (patient_data[:, 4] < 94)

high_risk_ids = patient_ids[high_risk_mask]

print("\nHigh-risk mask:")
print(high_risk_mask)

print("High-risk count:")
print(np.sum(high_risk_mask))

print("High-risk IDs:")
print(high_risk_ids)


# Min-Max normalization
minimum = clinical_features.min(axis=0)
maximum = clinical_features.max(axis=0)

normalized_features = (
    (clinical_features - minimum) /
    (maximum - minimum)
)

print("\nNormalized features:")
print(normalized_features)

print("\nNormalized shape:")
print(normalized_features.shape)

print("Minimum:", normalized_features.min())
print("Maximum:", normalized_features.max())


# Save patient data
np.save("week05/data/patient_data.npy", patient_data)

# Load patient data
loaded_data = np.load("week05/data/patient_data.npy")

print("\nNumpy file same:")
print(np.array_equal(patient_data, loaded_data))


# Save normalized data as CSV
np.savetxt(
    "week05/output/normalized_features.csv",
    normalized_features,
    delimiter=",",
    fmt="%.4f"
)

print("\nCSV file saved successfully.")


# Save and reload
# Save one NumPy array in binary format, preserving its shape and data type.
np.save("week05/data/patient_data.npy", patient_data)

# Load the saved NumPy array. 
loaded_npy = np.load("week05/data/patient_data.npy")

# Save normalized features as readable CSV values with four decimal places. 
np.savetxt(
    "week05/output/normalized_features.csv",
    normalized_features,
    delimiter=",",
    fmt="%.4f"
)

# Load numerical values from the CSV file. 
loaded_csv = np.loadtxt(
    "week05/output/normalized_features.csv",
    delimiter=","
)

# Verification
print("\nSave and Reload Verification:")
print("Numpy file exact match:",
      np.array_equal(patient_data, loaded_npy))

print("CSV values match:",
      np.allclose(normalized_features, loaded_csv))