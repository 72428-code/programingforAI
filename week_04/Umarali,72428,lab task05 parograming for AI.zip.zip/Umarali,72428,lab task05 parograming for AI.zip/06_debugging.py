import numpy as np


# F1: Incompatible shapes

a = np.ones((3, 4))
b = np.ones((3, 4))

result = a + b

print("F1 Result:")
print(result)


# F2: Boolean condition

values = np.array([10, 20, 30, 40])

selected = values[(values > 15) & (values < 35)]

print("\nF2 Result:")
print(selected)


# F3: Wrong axis

scores = np.array([
    [70, 80, 90],
    [60, 75, 85]
])

student_averages = np.mean(scores, axis=1)

print("\nF3 Result:")
print(student_averages)