import numpy as np

# Celsius to Fahrenheit
temperatures = np.array([20, 25, 30, 35, 40])

fahrenheit = temperatures * 9 / 5 + 32

print("Fahrenheit:")
print(fahrenheit)


# Add 5 bonus marks
marks = np.array([55, 67, 72, 88, 91])

adjusted = np.minimum(marks + 5, 100)

print("\nAdjusted marks:")
print(adjusted)


# Min-Max normalization
normalized = (marks - marks.min()) / (marks.max() - marks.min())

print("\nNormalized marks:")
print(normalized)


# Broadcasting
scores = np.array([
    [70, 75, 80],
    [60, 65, 70],
    [85, 90, 95]
])

bonus = np.array([2, 3, 5])

adjusted_scores = scores + bonus

print("\nAdjusted scores:")
print(adjusted_scores)